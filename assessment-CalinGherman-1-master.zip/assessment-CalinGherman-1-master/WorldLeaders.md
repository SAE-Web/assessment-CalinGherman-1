<table>
World Leaders You Should Know
<tr>
<td>First Name</td>
<td>Last Name</td>
<td>Official Title</td>
<td>Country</td>
<td>Date Appointed</td>
</tr>
<tr>
<td>Sanna</td>
<td>Marin</td>
<td>Prime Minister</td>
<td>Finland</td>
<td>10/12/2019</td>
</tr>
<tr>
<td>Sophie</td>
<td>Wilmés</td>
<td>Prime Minister</td>
<td>Belgium</td>
<td>27/10/2019</td>
</tr>
<tr>
<td>Paula-Mae</td>
<td>Weekes</td>
<td>President</td>
<td>Belgium</td>
<td>19/08/2018</td>
</tr>
<tr>
<td>Jacinda</td>
<td>Arden</td>
<td>Prime Minister</td>
<td>New Zealand</td>
<td>30/11/2017</td>
</tr>
<tr>
<td>Tsai</td>
<td>Ing-wen</td>
<td>President</td>
<td>Taiwan</td>
<td>20/05/2016</td>
</tr>
<tr>
<td>Angela</td>
<td>Merkel</td>
<td>Chancellor</td>
<td>Germany</td>
<td>22/11/2005</td>
</tr>
</table>