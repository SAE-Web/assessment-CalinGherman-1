let leaders = [
    {FirstName: 'Sanna',
LastName: 'Marin',
OfficialTitle: 'Prime Minister',
Country: 'Finland',
DateAppointed: '2019-12-10'
},
{FirstName: 'Sophie',
LastName: 'Wilmes',
OfficialTitle: 'Prime Minister',
Country: 'Belgium',
DateAppointed: '2019-10-27'
},
{FirstName: 'Paula-Mae',
LastName: 'Weekes',
OfficialTitle: 'President',
Country: 'Belgium',
DateAppointed: '2018-08-19'
},
{FirstName: 'Jacinda',
LastName: 'Arden',
OfficialTitle: 'Prime Minister',
Country: 'New Zealand',
DateAppointed: '2017-11-30'
},
{FirstName: 'Tsai',
LastName: 'Ing-wen',
OfficialTitle: 'President',
Country: 'Taiwan',
DateAppointed: '2016-05-20'
},
{FirstName: 'Angela',
LastName: 'Merkel',
OfficialTitle: 'Chancellor',
Country: 'Germany',
DateAppointed: '2005-11-22'
}
];

function leader(x){
    
    let name = leaders[0].FirstName + ' ' + leaders[0].LastName;
    let length = name + ' ' + name.length + " '-letters long'"
    console.log(length)
    return length
   
}
leader()



let button = document.querySelector('button');
let span = document.getElementById('display');

button.addEventListener('click', function(){
    for(let i = 0; i<=leaders.length; i++){
        console.log(leaders[i])
        let random = Math.floor((Math.random() * leaders[i]) + 1 )

span.textContent = random

    }

})

